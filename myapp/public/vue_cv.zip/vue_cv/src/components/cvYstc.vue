<template>
    <div class="ystc">
        <h2>优势特长 EXPERTISE</h2>
              <ul>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
                <li>
                    <img class="img " :src="imgUrl1">
                    <p>团队管理</p>
                </li>
              </ul>
    </div>
 </template>
 <script>
  export default{
     name:'cvYstc',
     data(){
         return {
             imgUrl1:require('../assets/未标题-1.png')
         }
     },
     methods: {
         
     },
  }
 </script>
 <style>
 .ystc{
    width: 1000px;
    height: 200px;
    margin-top: 20px;
    margin-left: 100px;
    margin: auto;
    
}
.ystc li img{
    width: 120px;
}
.ystc li p{
    width: 99px;
    height: 99px;
    top: 35px;
    left: 30px;
    position: absolute;
    color: #666666;
}
.ystc p:first-child{
    width: 99px;
    height: 99px;
    top: 115px;
    left: 100px;
    position: absolute;
    color: black;
}
.ystc ul{
    list-style-type: none;
    
}
.ystc li{
    position: relative;
    float: left;
    width: 150px;
    margin-left: 10px;
}
 </style>
 