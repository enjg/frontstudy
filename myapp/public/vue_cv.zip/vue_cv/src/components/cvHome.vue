<template>
    <div class="head">
        <img class="biaoqian" :src="imgUrl1">
        <div class="a1">
            <h1>Windir</h1>
            <p>实习</p>
            <p>前端开发方向</p>
        </div>
        <div class="left">
            <ul>
                <li>关于本人 ABOUT ME</li>
                <li>姓名&nbsp;&nbsp;{{name}}</li>
                <li>性别&nbsp;&nbsp;{{gender}}</li>
                <li>生日&nbsp;&nbsp;{{birthDay}}</li>
                <li>身高&nbsp;&nbsp;{{height}}</li>
                <li>籍贯&nbsp;&nbsp;{{placeOfBirth}}</li>
            </ul>
        </div>
        <div class="middle">
            <ul>
                <li>联系本人 CONTACT ME</li>
                <li><img :src="imgUrl2" >&nbsp;&nbsp;{{php}}</li>
                <li><img :src="imgUrl3">&nbsp;&nbsp;{{email}}</li>
                <li><img :src="imgUrl4">&nbsp;&nbsp;{{wchat}}</li>
                <li><img :src="imgUrl5">&nbsp;&nbsp;{{weibo}}</li>
                <li><img :src="imgUrl6">&nbsp;&nbsp;{{github}}</li>
            </ul>
        </div>
        <div class="right">
            <p>头像 HEAD PORTRAIT</p>
            <img :src="imgUrl7"  style="height: 200px;margin-top: 20px;">
        </div>
        <div class="a2">
            <img :src="imgUrl8">
        </div>
    </div>
</template>
<style>
.head{
    background-color: #1ABC9C;
    height: 616px;
    width: 1200px;
    margin: auto;
    margin-top: 163px;
    text-align: center;
}
.biaoqian{
    width: 200px;
    height: 200px;
    margin-top: -100px;
    
}
.a1{
    width: 1000px;
    height: 117px;
    margin: auto;
    margin-top: 10px;
    color: white;
    
    
}
.left{
    width: 290px;
    height: 282px;
    margin-top: 23px;
    float: left;
    margin-left: 100px;
}
.middle{
    width: 290px;
    height: 282px;
    margin-top: 23px;
    float: left;
    margin-left: 65px;
}
.right{
    width: 290px;
    height: 282px;
    margin-top: 23px;
    float: left;
    margin-left: 65px;
    color: white;
    margin-bottom: 10px;
}
.left ul{
    list-style-type: none;
    padding: 0;
    margin: 0;
    text-align: justify;
    color: white;
}
.left ul li{
    height: 47px;
    border-bottom: 1px solid white;
    line-height: 47px;
}
.middle ul{
    list-style-type: none;
    padding: 0;
    margin: 0;
    text-align: justify;
    color: white;
}
.middle ul li{
    height: 47px;
    border-bottom: 1px solid white;
    line-height: 47px;
}
.middle ul li img{
    height: 30px;
    margin-top: 10px;
}
.right p{
    border-bottom: 1px solid white;
    height: 47px;
    line-height: 47px;
    padding: 0;
    margin: 0;
}
.a2{
    width: 1200px;
    height: 59px;
    overflow: hidden;
    padding: 0;   
}
.a2 img{
    width: 100%;
    height: 100%;
}
</style>
<script>
 export default{
    name:'cvHome',
    data(){
        return {
            name:"黄杰",
            gender:"男",
            birthDay:"2002/04/30",
            height:"182cm",
            placeOfBirth:"重庆市垫江县",
            php:"176********",
            email:"",
            wchat:"",
            weibo:"",
            github:"",
            imgUrl1:require("../assets/未标题-2.png"),
            imgUrl2:require("../assets/电话.png"),
            imgUrl3:require("../assets/短信.png"),
            imgUrl4:require("../assets/微信.png"),
            imgUrl5:require("../assets/微博.png"),
            imgUrl6:require("../assets/github-fill.png"),
            imgUrl7:require("../assets/3.png"),
            imgUrl8:require("../assets/未标题-4.jpg"),
        }
    },
    methods: {
        
    },
 }
</script>