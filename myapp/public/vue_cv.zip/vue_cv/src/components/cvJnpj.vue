<template>
    <div class="jnpj">
        <h2>技能评价 SKILLS</h2>
        <div class="jnpj-left">
            <div class="jnpj-left-1 jnpj-1">
                <p>{{jn1}}</p>
                <img :src="imgUrl">
            </div>
            <div class="jnpj-left-2 jnpj-1">
                <p>{{jn2}}</p>
                <img :src="imgUrl">
            </div>
            <div class="jnpj-left-3 jnpj-1">
                <p>{{jn3}}</p>
                <img :src="imgUrl">
            </div>
        </div>
        <div class="jnpj-right">
            <div class="jnpj-right-1 jnpj-1">
                <p>{{jn4}}</p>
                <img :src="imgUrl">
            </div>
            <div class="jnpj-right-2 jnpj-1">
                <p>{{jn5}}</p>
                <img :src="imgUrl">
            </div>
            <div class="jnpj-right-3 jnpj-1">
                <p>{{jn6}}</p>
                <img :src="imgUrl">
            </div>
        </div>
    </div>
</template>
<script>
 export default{
    name:'cvJnpj',
    data(){
        return {
            
            imgUrl:require('../assets/未标题-1.jpg'),
            
                jn1:"Axure RP",
                jn2:"Visual Studio Code",
                jn3:"Adobe Photoshop",
                jn4:"Microsoft Office",
                jn5:"Microsoft Visio",
                jn6:"MySql"
        
            
        }
    },
    methods: {
        
    },
 }
</script>
<style>
.jnpj{
    width: 1000px;
    height: 300px;
    margin-left: 100px;
    margin-top: 20px;
    color: #666666;
    margin: auto;
}
.jnpj-left{
    width: 300px;
    height: 240px;
    float: left;
    margin-left: 110px;
}
.jnpj-right{
    width: 300px;
    height: 240px;
    float: left;
    margin-left: 210px;
}
.jnpj-1{
    width: 300px;
    height: 50px;
    margin-top: 30px;
}
.jnpj p{
    width: 300px;
    height: 40px;
    font-size: 16px;
    margin-bottom: -7px;
}
.jnpj img{
    width: 300px;
    height: 10px;
}
</style>
