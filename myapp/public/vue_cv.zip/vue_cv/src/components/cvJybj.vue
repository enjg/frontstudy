<template>
     <div class="jybj">
        <h2>教育背景 EDUCATION</h2>
        <div class="c1">
            <h3>{{bysj}}<br>
                 <p class="p1">{{zy}}</p>
        </h3>
        </div>
        <div class="c2">
            <p class="p1">{{school}}</p>
            <p>{{curriculum}}</p>
        </div>
        <div class="jybj-left">
            <p class="p1">证书技能</p>
            <ul>
                <li><span>123</span></li>
                <li><span>123</span></li>
                <li><span>123</span></li>
                <li><span>掌握HTML5、Javascript、MySql</span></li>
            </ul>
        </div>
        <div class="jybj-right">
            <p class="p1">获得奖项</p>
            <ul>
                <li><span>123</span></li>
                <li><span>123</span></li>
                <li><span>123</span></li>
                <li><span>123</span></li>
            </ul>
        </div>
    </div>
 </template>
 <script>
  export default{
     name:'cvJybj',
     data(){
         return {
            bysj:"2020/09-2023/07",
            zy:"计算机应用技术",
            school:"重庆航天职业技术学院",
            curriculum:"主修课程：HTML5与CSS3、C#、jQuery、SQL Server、ASP.NEP、PHP、Bootstrap、Unity 3D、数据结构、计算机基础"
         }
     },
     methods: {
         
     },
  }
 </script>
 <style>
 .jybj{
    width: 1000px;
    height: 403px;
    margin-left: 100px;
    color: #666666;
    margin: auto;
}
.jybj h3{
    text-align: right;
    float: left;
    
}

.c1{
    width: 192px;
    height: 96px;
    margin-left: 12px;
    float: left;
    margin-top: 20px;
}
.c2{
    width: 786px;
    height: 118px;
    float: left;
    margin-left: 10px;
    font-size: 16;
    margin-top: 20px;
}
.p1{
    font-weight: bold;
    font-size: 16px;
}
.cenvent{
    width: 1200px;
    margin: auto;
}
.jybj-left{
    width: 380px;
    height: 185px;
    margin-left: 50px;
    margin-top: 20px;
    float: left;
}
.jybj-right{
    width: 380px;
    height: 185px;
    margin-left: 140px;
    margin-top: 20px;
    float: left;
}
.jybj p{
    font-size: 16px;
    margin-left: 60px;
}
.jybj li{
    color: #1ABC9C;
    margin-left: 80px;
    font-size: 16px;
}
.jybj span{
    color: #666666;
}
.jybj ul{
    margin: 0;
    padding: 0;
}
.jybj li::marker{
    font-size: 25px;
}
 </style>
 