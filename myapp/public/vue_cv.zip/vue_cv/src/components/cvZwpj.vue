<template>
   <div class="zwpj">
        <h2>自我评价 PROFILE</h2>
        <p>自信、乐观、责任心强。具有较好的团队组织能力、分析问题和宣传策划活动能力、协调能力等。学习方面也有较强的求知欲与良好的学习能力。为人真诚，惯于换位思考;对自己要求严格，做事情讲究效率;对程序的开发及测试方面很感兴趣;有较强的学习能力，适应行业的要求和新技术的挑战;有较强的求知欲、较强的、学习能力。</p>
    </div> 
</template>
<script>
 export default{
    name:'cvZwpj',
    data(){
        return {
            
        }
    },
    methods: {
        
    },
 }
</script>
<style>
.zwpj{
    width: 1000px;
    height: 192px;
    margin-top: 20px;
    margin-left: 100px;
    margin: auto;
    
}
h2{
    height: 60px;
    color: #000000;
    margin: 0;
    padding: 0;
}
.zwpj p{
    margin-top: 20px;
    margin-left: 5px;
    height: 112px;
    color: #666666;
}
</style>
