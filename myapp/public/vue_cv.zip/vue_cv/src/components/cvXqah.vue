<template>
    <div class="xqah">
        <h2>兴趣爱好 INTEREST</h2>
        <div class="xqah-1">
            <div class="xqah-img">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl2">
                <p>互联网</p>
            </div>
            
            <div class="xqah-img xqah-img-2">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl3">
                <p>健身</p>
            </div>

            <div class="xqah-img xqah-img-2">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl4">
                <p>音乐</p>
            </div>

            <div class="xqah-img xqah-img-2">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl5">
                <p>看书</p>
            </div>

            <div class="xqah-img xqah-img-2">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl6">
                <p>旅行</p>
            </div>

            <div class="xqah-img xqah-img-2">
                <img :src="imgUrl1">
                <img style="width: 46px; height: 46px;margin: 12px 37px;" :src="imgUrl7">
                <p>电影</p>
            </div>
            
        </div>
    </div>
</template>
<script>
 export default{
    name:'cvXqah',
    data(){
        return {
            imgUrl1:require('../assets/圆-背景.png'),
            imgUrl2:require('../assets/互联网 IT.png'),
            imgUrl3:require('../assets/健身.png'),
            imgUrl4:require('../assets/音乐.png'),
            imgUrl5:require('../assets/阅读.png'),
            imgUrl6:require('../assets/旅行.png'),
            imgUrl7:require('../assets/电影.png')
        }
    },
    methods: {
        
    },
 }
</script>
<style>
.xqah{
    width: 1000px;
    height: 310px;
    margin-left: 100px;
    margin-top: 48px;
    margin: auto;
}
.xqah-1{
    width: 771px;
    height: 120px;
    margin-top: 42px;
    margin-left: 84px;
}
.xqah-img{
    width: 121px;
    height: 120px;
    float: left;
}
.xqah img{
    position: absolute;
    mix-blend-mode: soft-light;
    margin: 0;
    width: 70px;
    height: 70px;
    margin-left: 25px;
}
.xqah p{
    width: 121px;
    height: 40px;
    margin-top: 80px;
    color: #666666;
    text-align: center;
}
.xqah-img-2{
    margin-left: 9px;
}
</style>
