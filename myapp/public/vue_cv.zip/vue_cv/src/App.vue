<template>
  <div>
    <cvHome></cvHome>
    <cvZwpj></cvZwpj>
    <cvYstc></cvYstc>
    <cvJybj></cvJybj>
    <cvJnpj></cvJnpj>
    <cvXqah></cvXqah>
  </div>
</template>

<script>
import cvHome from'./components/cvHome.vue'
import cvZwpj from'./components/cvZwpj.vue'
import cvYstc from'./components/cvYstc.vue'
import cvJybj from'./components/cvJybj.vue'
import cvJnpj from'./components/cvJnpj.vue'
import cvXqah from'./components/cvXqah.vue'
export default {
    name:'App',
    components:{
        cvHome,
        cvZwpj,
        cvYstc,
        cvJybj,
        cvJnpj,
        cvXqah
    }
}
</script>

<style>

</style>